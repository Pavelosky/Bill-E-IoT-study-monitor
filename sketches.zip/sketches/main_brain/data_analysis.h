#ifndef DATA_ANALYSIS_H
#define DATA_ANALYSIS_H

void analyzeEnvironment();
void analyzeBiometrics();

#endif