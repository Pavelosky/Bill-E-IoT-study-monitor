#ifndef AUDIO_SYSTEM_H
#define AUDIO_SYSTEM_H

void playSessionStartSound();
void playAuthFailSound();
void playWorkSessionStartSound();
void playBreakStartSound();
void playLongBreakStartSound();
void playSessionCompleteSound();
void playReminderSound();
void playAlertSound();
void playTouchAcknoledgmentSound();

#endif