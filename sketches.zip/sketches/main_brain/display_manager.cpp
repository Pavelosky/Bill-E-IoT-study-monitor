#include "display_manager.h"
#include "data_structures.h"
#include "pomodoro_timer.h"
#include <LiquidCrystal_I2C.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>

extern LiquidCrystal_I2C lcd;
extern PubSubClient mqttClient;

void updateDisplay() {
  if (sessionActive) {
    // Show session info with environmental and biometric data
    unsigned long elapsed = (millis() - sessionStart) / 1000;
    int minutes = elapsed / 60;
    int seconds = elapsed % 60;
    
    static unsigned long lastDisplaySwitch = 0;
    static int displayMode = 0;
    
    // Switch between different data views every 3 seconds
    if (millis() - lastDisplaySwitch > 3000) {
      displayMode = (displayMode + 1) % 2;
      lastDisplaySwitch = millis();
      lcd.clear();
    }

    switch (displayMode) {
      case 0:
        // Pomodoro timer info
        lcd.setCursor(0, 0);
        if (pomodoro.awaitingConfirmation) {
          lcd.print("TOUCH TO CONTINUE");
          lcd.setCursor(0, 1);
          lcd.print("Timer Complete!    "); // Extra spaces to clear previous text
        } else {
          // Pre-calculate state text
          const char* stateText;
          switch (pomodoro.currentState) {
            case WORK_SESSION: stateText = "WORK        "; break;  // Pad with spaces
            case SHORT_BREAK: stateText = "BREAK       "; break;
            case LONG_BREAK: stateText = "LONG BREAK  "; break;
            default: stateText = "IDLE        "; break;
          }
          lcd.print(stateText);
          
          lcd.setCursor(0, 1);
          lcd.print("Time: " + getTimeRemainingText());
      
          if (pomodoro.breakSnoozed && pomodoro.snoozeCount > 0) {
            lcd.setCursor(14, 1);
            lcd.printf("S%d", pomodoro.snoozeCount);
          }
        }
        break;
        
      case 1:
        // Biometric data
        if (bioData.dataAvailable) {
          lcd.setCursor(0, 0);
          lcd.printf("HR:%d Steps:%d", bioData.heartRate, bioData.stepCount);
          lcd.setCursor(0, 1);
          lcd.print("Act: " + bioData.activity.substring(0, 10));
        } else {
          lcd.setCursor(0, 0);
          lcd.print("Biometric");
          lcd.setCursor(0, 1);
          lcd.print("No Data");
        }
        break;

    }
  }
}

// Show welcome screen
void showWelcomeScreen() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Bill-E Focus Bot");
  lcd.setCursor(0, 1);
  lcd.print("Scan RFID card");
}

void forceSwitchDisplay() {
  static int displayMode = 0;
  displayMode = (displayMode + 1) % 5;
  // Force immediate display update by resetting the timer
  static unsigned long lastDisplaySwitch = 0;
  lastDisplaySwitch = millis() - 2000; // Force next update cycle
}
