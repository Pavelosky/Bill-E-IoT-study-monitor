#ifndef DISPLAY_CONTROLLER_H
#define DISPLAY_CONTROLLER_H

#include <PubSubClient.h>

void displayEnvironment();
void printEnvironment();

extern PubSubClient client;

#endif